# ReliefGrid submission

The primary deliverable is [ReliefGrid_Submission.ipynb](ReliefGrid_Submission.ipynb). Its implementation, scenarios and measured outputs are self-contained.

The five-minute presentation is [ReliefGrid_Presentation.pptx](ReliefGrid_Presentation.pptx).

See [setup, model and reproduction instructions](reliefgrid/README.md) and [recorded verification](reliefgrid/docs/VERIFICATION.md). The optional Flask workbench includes a compiled frontend. Install its Python dependencies, then use Launch ReliefGrid.cmd.

SHA256SUMS.json covers the notebook, presentation, and every other submission file.
